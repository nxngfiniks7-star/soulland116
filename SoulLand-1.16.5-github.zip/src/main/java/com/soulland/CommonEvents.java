package com.soulland;

import java.util.Random;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SoulLand.MODID)
public class CommonEvents {
    private static final Random R = new Random();
    private static final float[][] RC = {{1, 1, 1}, {1, 0.84f, 0}, {0.6f, 0.2f, 1}, {0.1f, 0.1f, 0.1f}, {1, 0.1f, 0.1f}};

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayerEntity)) return;
        ServerPlayerEntity p = (ServerPlayerEntity) e.getPlayer();
        SoulData.setMed(p, false);
        SoulLogic.applyHp(p, false);
        Net.sync(p);
    }

    @SubscribeEvent
    public static void logout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getPlayer() instanceof ServerPlayerEntity) SoulLogic.stopMeditate((ServerPlayerEntity) e.getPlayer(), false);
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        CompoundNBT old = e.getOriginal().getPersistentData();
        if (old.contains(SoulData.KEY)) {
            e.getPlayer().getPersistentData().put(SoulData.KEY, old.getCompound(SoulData.KEY).copy());
            SoulData.setActive(e.getPlayer(), false);
            SoulData.setRingsOn(e.getPlayer(), false);
            SoulData.setMed(e.getPlayer(), false);
        }
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getPlayer() instanceof ServerPlayerEntity) {
            ServerPlayerEntity p = (ServerPlayerEntity) e.getPlayer();
            SoulLogic.applyHp(p, true);
            Net.sync(p);
        }
    }

    @SubscribeEvent
    public static void death(LivingDeathEvent e) {
        if (e.getEntityLiving() instanceof PlayerEntity) return;
        if (e.getSource().getEntity() instanceof ServerPlayerEntity) {
            ServerPlayerEntity p = (ServerPlayerEntity) e.getSource().getEntity();
            SoulLogic.addXp(p, Math.max(1, (int) (e.getEntityLiving().getMaxHealth() / 2)));
        }
    }

    @SubscribeEvent
    public static void drops(LivingDropsEvent e) {
        LivingEntity v = e.getEntityLiving();
        if (v instanceof PlayerEntity) return;
        if (!(e.getSource().getEntity() instanceof ServerPlayerEntity)) return;
        float hp = v.getMaxHealth();
        double chance = hp >= 100 ? 1.0 : 0.05;
        if (R.nextDouble() >= chance) return;
        int idx = hp >= 300 ? 4 : hp >= 100 ? 3 : hp >= 40 ? 2 : hp >= 20 ? 1 : 0;
        ItemStack s = new ItemStack(ModItems.RINGS.get(idx).get());
        e.getDrops().add(new ItemEntity(v.level, v.getX(), v.getY(), v.getZ(), s));
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level.isClientSide) return;
        if (!(e.player instanceof ServerPlayerEntity)) return;
        ServerPlayerEntity p = (ServerPlayerEntity) e.player;
        if (SoulData.spirit(p) < 0) return;
        if (SoulData.med(p)) SoulLogic.meditateTick(p);
        if (p.tickCount % 20 == 0) {
            float max = SoulData.maxMana(SoulData.level(p));
            float m = Math.min(max, SoulData.mana(p) + 1 + SoulData.level(p) / 20f);
            if (m != SoulData.mana(p)) { SoulData.setMana(p, m); Net.sync(p); }
        }
        if (SoulData.ringsOn(p) && p.tickCount % 8 == 0) {
            int[] r = SoulData.rings(p);
            ServerWorld w = (ServerWorld) p.level;
            for (int i = 0; i < r.length; i++) {
                float[] c = RC[Math.max(0, Math.min(4, r[i]))];
                double a = (p.tickCount / 10.0) + i * (Math.PI * 2 / Math.max(1, r.length));
                double ox = Math.cos(a) * 0.9, oz = Math.sin(a) * 0.9;
                w.sendParticles(new RedstoneParticleData(c[0], c[1], c[2], 1.0f), p.getX() + ox, p.getY() + 0.2 + i * 0.12, p.getZ() + oz, 1, 0, 0, 0, 0);
            }
        }
    }
}
