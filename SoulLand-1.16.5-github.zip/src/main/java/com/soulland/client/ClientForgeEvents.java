package com.soulland.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.soulland.Net;
import com.soulland.SoulData;
import com.soulland.SoulLand;
import com.soulland.Spirit;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SoulLand.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;
        while (Keys.TOGGLE.consumeClick()) Net.CH.sendToServer(new Net.ActionMsg(0));
        while (Keys.CAST.consumeClick()) Net.CH.sendToServer(new Net.ActionMsg(1));
        while (Keys.RINGS.consumeClick()) Net.CH.sendToServer(new Net.ActionMsg(3));
        while (Keys.NEXT.consumeClick()) Net.CH.sendToServer(new Net.ActionMsg(2));
    }

    @SubscribeEvent
    public static void hud(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        PlayerEntity p = mc.player;
        MatrixStack ms = e.getMatrixStack();
        FontRenderer f = mc.font;
        int x = 6, y = 6;
        int sp = SoulData.spirit(p);
        Spirit s = Spirit.byId(sp);
        if (s == null) {
            f.drawShadow(ms, "ยังไม่ตื่นรู้วิญญาณยุทธ์ (ใช้หินตื่นรู้)", x, y, 0xFFFFFF);
            return;
        }
        int lv = SoulData.level(p);
        f.drawShadow(ms, s.thName + (SoulData.active(p) ? " [เปิด]" : " [ปิด]") + "  วงแหวน" + (SoulData.ringsOn(p) ? " [เปิด]" : " [ปิด]"), x, y, s.color);
        f.drawShadow(ms, "เลเวล " + lv + "  EXP " + SoulData.xp(p) + "/" + (20 + lv * 15), x, y + 10, 0xFFFFFF);
        float max = SoulData.maxMana(lv);
        int wd = (int) (80 * Math.min(1f, SoulData.mana(p) / max));
        AbstractGui.fill(ms, x, y + 22, x + 80, y + 28, 0xFF222222);
        AbstractGui.fill(ms, x, y + 22, x + wd, y + 28, 0xFF3399FF);
        int[] r = SoulData.rings(p);
        int unlocked = Math.min(r.length, s.skills.length);
        if (sp == 3) unlocked = 1;
        int sel = SoulData.sel(p);
        String sk = unlocked > 0 && sel < unlocked ? "ทักษะ " + (sel + 1) + ": " + s.skills[sel] : "ยังไม่มีทักษะ";
        f.drawShadow(ms, sk, x, y + 34, 0xFFFFAA);
    }
}
