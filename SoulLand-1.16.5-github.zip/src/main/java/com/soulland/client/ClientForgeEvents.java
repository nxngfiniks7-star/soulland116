package com.soulland.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.soulland.Net;
import com.soulland.SoulData;
import com.soulland.SoulLand;
import com.soulland.SoulLogic;
import com.soulland.Spirit;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SoulLand.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {

    private static void send(int a) { Net.CH.sendToServer(new Net.ActionMsg(a)); }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;
        while (Keys.TOGGLE.consumeClick()) send(0);
        while (Keys.CAST.consumeClick()) send(1);
        while (Keys.NEXT.consumeClick()) send(2);
        while (Keys.RINGS.consumeClick()) send(3);
        while (Keys.MEDITATE.consumeClick()) send(4);
        while (Keys.AWAKEN.consumeClick()) send(5);
        while (Keys.REROLL.consumeClick()) send(6);
    }

    /** ซ่อนหัวใจของเกม (เลือดเยอะเกินจะทับจอ) ใช้แถบเลือดใน HUD แทน */
    @SubscribeEvent
    public static void pre(RenderGameOverlayEvent.Pre e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.HEALTH) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && SoulData.spirit(mc.player) >= 0) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void hud(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        PlayerEntity p = mc.player;
        MatrixStack ms = e.getMatrixStack();
        FontRenderer f = mc.font;
        int x = 6, y = 6;
        Spirit s = Spirit.byId(SoulData.spirit(p));
        if (s == null) {
            f.drawShadow(ms, "ยังไม่มีวิญญาณยุทธ์", x, y, 0xFFFFFF);
            f.drawShadow(ms, "กด M เพื่อปลูกวิญญาณยุทธ์", x, y + 11, 0xFFDD55);
            return;
        }
        int lv = SoulData.level(p);
        int rings = SoulData.rings(p).length;
        f.drawShadow(ms, s.thName + (SoulData.active(p) ? " [เปิด]" : " [ปิด]") + "  วงแหวน" + (SoulData.ringsOn(p) ? " [เปิด]" : " [ปิด]"), x, y, s.color);
        y += 11;
        f.drawShadow(ms, "เลเวล " + lv + "  EXP " + SoulData.xp(p) + "/" + SoulLogic.need(lv) + "  วงแหวน " + rings + "/9", x, y, 0xFFFFFF);
        y += 12;
        // แถบเลือด
        float hp = p.getHealth(), mhp = Math.max(1f, p.getMaxHealth());
        AbstractGui.fill(ms, x, y, x + 100, y + 10, 0xFF330000);
        AbstractGui.fill(ms, x, y, x + (int) (100 * Math.min(1f, hp / mhp)), y + 10, 0xFFCC2222);
        f.drawShadow(ms, "HP " + (int) Math.ceil(hp) + "/" + (int) Math.ceil(mhp), x + 3, y + 1, 0xFFFFFF);
        y += 13;
        // แถบมานา
        float mm = SoulData.maxMana(lv);
        AbstractGui.fill(ms, x, y, x + 100, y + 7, 0xFF222222);
        AbstractGui.fill(ms, x, y, x + (int) (100 * Math.min(1f, SoulData.mana(p) / mm)), y + 7, 0xFF3399FF);
        y += 11;
        int unlocked = s.skills.length == 1 ? 1 : Math.min(rings, s.skills.length);
        int sel = SoulData.sel(p);
        String sk = unlocked > 0 && sel < unlocked ? "ทักษะ " + (sel + 1) + ": " + s.skills[sel] : "ยังไม่มีทักษะ (ต้องมีวงแหวน)";
        f.drawShadow(ms, sk, x, y, 0xFFFFAA);
        y += 11;
        if (lv >= SoulLogic.levelCap(rings) && rings < 9) {
            f.drawShadow(ms, "ถึงคอขวด! ต้องดูดซับวงแหวน", x, y, 0xFF8800);
            y += 11;
        }
        if (SoulData.med(p)) f.drawShadow(ms, "กำลังนั่งฝึก (กด K หยุด)", x, y, 0x88CCFF);
    }
}
