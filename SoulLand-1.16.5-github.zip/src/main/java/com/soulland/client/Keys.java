package com.soulland.client;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.settings.KeyBinding;

public class Keys {
    public static final KeyBinding TOGGLE = new KeyBinding("key.soulland.toggle", GLFW.GLFW_KEY_V, "key.categories.soulland");
    public static final KeyBinding CAST = new KeyBinding("key.soulland.cast", GLFW.GLFW_KEY_R, "key.categories.soulland");
    public static final KeyBinding RINGS = new KeyBinding("key.soulland.rings", GLFW.GLFW_KEY_B, "key.categories.soulland");
    public static final KeyBinding NEXT = new KeyBinding("key.soulland.next", GLFW.GLFW_KEY_G, "key.categories.soulland");
}
