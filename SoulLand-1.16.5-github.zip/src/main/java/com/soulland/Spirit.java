package com.soulland;

public enum Spirit {
    BLUE_SILVER("ต้นไม้เงินคราม", 0x4DA6FF, new String[]{"พันธนาการเถา", "เถาสมานชีวิต", "ฟาดเถาเงิน", "ป่าเถาคราม"}),
    HAMMER("ค้อนฮ่าวเทียน", 0xFFD700, new String[]{"ทุบพื้นสะท้านดิน", "พลังค้อนสุริยัน", "สายฟ้าฮ่าวเทียน", "ร่างทองคำ"}),
    RABBIT("กระต่ายอรชร", 0xFF99CC, new String[]{"เคลื่อนที่พริบตา", "กายทิพย์", "กระโดดอรชร", "รัชนีกรเก้าชั้นฟ้า"}),
    JUNK("ต้นหญ้า", 0xAAAAAA, new String[]{"แรงเฮือกสุดท้าย"});

    public final String thName;
    public final int color;
    public final String[] skills;

    Spirit(String n, int c, String[] s) {
        thName = n;
        color = c;
        skills = s;
    }

    public static Spirit byId(int id) {
        Spirit[] v = values();
        return (id >= 0 && id < v.length) ? v[id] : null;
    }
}
