package com.soulland;

import java.util.Random;

public enum Spirit {
    BLUE_SILVER("หญ้าสีเงินคราม", 0x4DA6FF, "item:minecraft:fern", 0.9, 1.6, false, 10,
            "พันธนาการเถาเงิน", "เถาสมานชีวิต", "แส้หญ้าเงิน", "อาณาเขตหญ้าเงินคราม"),
    HAMMER("ค้อนฮ่าวเทียน", 0xFFD700, null, 0, 1, true, 10,
            "ค้อนฮ่าวเทียนทุบพสุธา", "พลังโทสะฮ่าวเทียน", "สายฟ้าฮ่าวเทียน", "ร่างทองฮ่าวเทียน"),
    RABBIT("กระต่ายอรชร", 0xFF99CC, "mob:minecraft:rabbit", 0.8, 1.4, false, 8,
            "เคลื่อนที่พริบตา", "กายทิพย์", "อรชรกระโดด", "รัชนีกรเก้าชั้นฟ้า"),
    TIGER("พยัคฆ์ขาว", 0xE0E0E0, "mob:minecraft:ocelot", 1.1, 1.8, false, 8,
            "กรงเล็บพยัคฆ์", "คำรามพยัคฆ์", "พยัคฆ์พุ่งทะยาน", "พยัคฆ์คลั่ง"),
    ZOMBIE("ซอมบี้", 0x66DD66, "mob:minecraft:zombie", 0.9, 1.15, false, 4,
            "ทุบมรณะ", "ฟื้นฟูซากศพ", "ลมหายใจเน่า", "ผิวหนังด้าน"),
    SKELETON("โครงกระดูก", 0xDDDDDD, "mob:minecraft:skeleton", 0.9, 1.15, false, 4,
            "เศษกระดูกกระจาย", "ว่องไวไร้เนื้อ", "ม่านกระดูก", "กระดูกแกร่ง"),
    CREEPER("ครีปเปอร์", 0x55EE55, "mob:minecraft:creeper", 0.9, 1.15, false, 4,
            "ระเบิดสะท้านดิน", "เกราะเขียว", "คลื่นระเบิด", "ดีดตัวขึ้นฟ้า"),
    SPIDER("แมงมุม", 0xFF5544, "mob:minecraft:spider", 1.3, 1.05, false, 4,
            "ใยแมงมุม", "พิษแมงมุม", "ปีนป่าย", "ล่าเหยื่อ"),
    ENDERMAN("เอนเดอร์แมน", 0xBB66FF, "mob:minecraft:enderman", 0.9, 1.0, false, 4,
            "เคลื่อนย้ายมิติ", "ล่องหนเอนเดอร์", "ฟาดความว่างเปล่า", "ร่างเงา"),
    BLAZE("เบลซ", 0xFFAA22, "mob:minecraft:blaze", 0.9, 1.15, false, 4,
            "เปลวเพลิงล้อมกาย", "กายาทนไฟ", "ลูกไฟพิโรธ", "ร่างอัคคี"),
    IRON_GOLEM("ไอร่อนโกเลม", 0xCCCCCC, "mob:minecraft:iron_golem", 1.2, 0.85, false, 4,
            "ทุบเหล็กกล้า", "ผิวเหล็ก", "เกราะดูดซับ", "พลังยักษ์"),
    AXE("ขวาน", 0xAAAAAA, "item:minecraft:iron_axe", 0.9, 1.4, false, 4, "พลังขวาน"),
    PICKAXE("ที่ขุด", 0xAAAAAA, "item:minecraft:iron_pickaxe", 0.9, 1.4, false, 4, "พลังขุด"),
    SHOVEL("พลั่ว", 0xAAAAAA, "item:minecraft:iron_shovel", 0.9, 1.4, false, 4, "พลังพลั่ว"),
    HOE("จอบ", 0xAAAAAA, "item:minecraft:iron_hoe", 0.9, 1.4, false, 4, "พลังจอบ");

    public final String thName;
    public final int color;
    public final String render;
    public final double dist;
    public final double scale;
    public final boolean weapon;
    public final int weight;
    public final String[] skills;

    Spirit(String n, int c, String render, double dist, double scale, boolean weapon, int weight, String... skills) {
        this.thName = n;
        this.color = c;
        this.render = render;
        this.dist = dist;
        this.scale = scale;
        this.weapon = weapon;
        this.weight = weight;
        this.skills = skills;
    }

    public static Spirit byId(int id) {
        Spirit[] v = values();
        return (id >= 0 && id < v.length) ? v[id] : null;
    }

    public static Spirit roll(Random r, Spirit exclude) {
        int total = 0;
        for (Spirit s : values()) if (s != exclude) total += s.weight;
        int x = r.nextInt(total);
        for (Spirit s : values()) {
            if (s == exclude) continue;
            x -= s.weight;
            if (x < 0) return s;
        }
        return BLUE_SILVER;
    }
}
