package com.soulland;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTier;
import net.minecraft.item.SwordItem;
import net.minecraft.util.ActionResult;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SoulLand.MODID);

    private static Item.Properties props() {
        return new Item.Properties().tab(ItemGroup.TAB_MISC);
    }

    public static final List<RegistryObject<Item>> RINGS = new ArrayList<>();
    static {
        String[] n = {"white", "yellow", "purple", "black", "red"};
        for (int i = 0; i < n.length; i++) {
            final int idx = i;
            RINGS.add(ITEMS.register(n[i] + "_ring", () -> new RingItem(props(), idx)));
        }
    }

    public static final RegistryObject<Item> HAMMER = ITEMS.register("haotian_hammer",
            () -> new SwordItem(ItemTier.DIAMOND, 9, -3.0F, new Item.Properties().tab(ItemGroup.TAB_COMBAT)));

    public static class RingItem extends Item {
        public final int idx;
        public RingItem(Properties p, int idx) { super(p); this.idx = idx; }

        @Override
        public ActionResult<ItemStack> use(World w, PlayerEntity p, Hand h) {
            ItemStack s = p.getItemInHand(h);
            if (!w.isClientSide && p instanceof ServerPlayerEntity) {
                if (SoulLogic.absorbRing((ServerPlayerEntity) p, idx)) s.shrink(1);
            }
            return new ActionResult<>(ActionResultType.SUCCESS, s);
        }
    }
}
