package com.soulland;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.CompoundNBT;

public class SoulData {
    public static final String KEY = "soulland";

    public static CompoundNBT tag(PlayerEntity p) {
        CompoundNBT root = p.getPersistentData();
        if (!root.contains(KEY)) root.put(KEY, new CompoundNBT());
        return root.getCompound(KEY);
    }

    public static int spirit(PlayerEntity p) {
        CompoundNBT t = tag(p);
        return t.contains("spirit") ? t.getInt("spirit") : -1;
    }

    public static void setSpirit(PlayerEntity p, int v) { tag(p).putInt("spirit", v); }

    public static int level(PlayerEntity p) { return Math.max(1, tag(p).getInt("level")); }
    public static void setLevel(PlayerEntity p, int v) { tag(p).putInt("level", v); }

    public static int xp(PlayerEntity p) { return tag(p).getInt("xp"); }
    public static void setXp(PlayerEntity p, int v) { tag(p).putInt("xp", v); }

    public static int[] rings(PlayerEntity p) { return tag(p).getIntArray("rings"); }
    public static void setRings(PlayerEntity p, int[] v) { tag(p).putIntArray("rings", v); }

    public static boolean active(PlayerEntity p) { return tag(p).getBoolean("active"); }
    public static void setActive(PlayerEntity p, boolean v) { tag(p).putBoolean("active", v); }

    public static boolean ringsOn(PlayerEntity p) { return tag(p).getBoolean("ringsOn"); }
    public static void setRingsOn(PlayerEntity p, boolean v) { tag(p).putBoolean("ringsOn", v); }

    public static float mana(PlayerEntity p) { return tag(p).getFloat("mana"); }
    public static void setMana(PlayerEntity p, float v) { tag(p).putFloat("mana", v); }

    public static float maxMana(int level) { return 20 + level * 3; }

    public static int sel(PlayerEntity p) { return tag(p).getInt("sel"); }
    public static void setSel(PlayerEntity p, int v) { tag(p).putInt("sel", v); }

    public static long cd(PlayerEntity p) { return tag(p).getLong("cd"); }
    public static void setCd(PlayerEntity p, long v) { tag(p).putLong("cd", v); }

    public static boolean given(PlayerEntity p) { return tag(p).getBoolean("given"); }
    public static void setGiven(PlayerEntity p, boolean v) { tag(p).putBoolean("given", v); }
}
