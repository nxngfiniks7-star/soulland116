package com.soulland;

import java.util.function.Supplier;

import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.network.NetworkEvent;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraftforge.fml.network.simple.SimpleChannel;

public class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SoulLand.MODID, "main"), () -> V, V::equals, V::equals);

    public static void register() {
        CH.registerMessage(0, ActionMsg.class, ActionMsg::enc, ActionMsg::dec, ActionMsg::handle);
        CH.registerMessage(1, SyncMsg.class, SyncMsg::enc, SyncMsg::dec, SyncMsg::handle);
    }

    public static void sync(ServerPlayerEntity p) {
        CompoundNBT t = SoulData.tag(p).copy();
        CH.send(PacketDistributor.PLAYER.with(() -> p), new SyncMsg(t));
    }

    public static class ActionMsg {
        public final int action;
        public ActionMsg(int a) { action = a; }
        public static void enc(ActionMsg m, PacketBuffer b) { b.writeInt(m.action); }
        public static ActionMsg dec(PacketBuffer b) { return new ActionMsg(b.readInt()); }
        public static void handle(ActionMsg m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayerEntity p = c.getSender();
                if (p == null) return;
                if (m.action == 0) SoulLogic.toggle(p);
                else if (m.action == 1) SoulLogic.cast(p);
                else if (m.action == 2) SoulLogic.nextSkill(p);
                else if (m.action == 3) SoulLogic.toggleRings(p);
                else if (m.action == 4) SoulLogic.toggleMeditate(p);
                else if (m.action == 5) SoulLogic.awaken(p, false);
                else if (m.action == 6) SoulLogic.requestReroll(p);
            });
            c.setPacketHandled(true);
        }
    }

    public static class SyncMsg {
        public final CompoundNBT tag;
        public SyncMsg(CompoundNBT t) { tag = t; }
        public static void enc(SyncMsg m, PacketBuffer b) { b.writeNbt(m.tag); }
        public static SyncMsg dec(PacketBuffer b) { return new SyncMsg(b.readNbt()); }
        public static void handle(SyncMsg m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.soulland.client.ClientHooks.sync(m.tag)));
            c.setPacketHandled(true);
        }
    }
}
